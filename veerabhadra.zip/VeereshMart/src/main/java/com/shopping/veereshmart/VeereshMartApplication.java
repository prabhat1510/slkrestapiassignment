package com.shopping.veereshmart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VeereshMartApplication {

	public static void main(String[] args) {
		SpringApplication.run(VeereshMartApplication.class, args);
	}

}
