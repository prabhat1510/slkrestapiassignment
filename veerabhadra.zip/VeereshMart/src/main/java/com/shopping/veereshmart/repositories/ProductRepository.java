package com.shopping.veereshmart.repositories;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.shopping.veereshmart.entities.Product;

@Repository
public interface ProductRepository extends CrudRepository<Product, Integer> {
    
    // Remove the unnecessary parameter from the method
    @Query("SELECT p FROM Product p WHERE p.category = 'Games' AND p.price > 100")
    List<Product> findExpensiveGames(); // Updated method name for clarity
    
    @Query("SELECT p FROM Product p WHERE p.category = 'Toys'")
    List<Product> findProductsByCategoryToys();
    
    @Query("SELECT p FROM Product p JOIN p.orders o JOIN o.customer c " +
            "WHERE c.tier = 2 AND o.orderDate BETWEEN :startDate AND :endDate")
     List<Product> findProductsOrderedByTier2CustomersWithinDateRange(LocalDate startDate, LocalDate endDate);
    
    @Query("SELECT p FROM Product p WHERE p.category = 'Games' AND p.price = (SELECT MIN(p2.price) FROM Product p2 WHERE p2.category = 'Games')")
    List<Product> findCheapestBooks();
}
