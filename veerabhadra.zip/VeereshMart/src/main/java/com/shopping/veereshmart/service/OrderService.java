package com.shopping.veereshmart.service;

import java.util.List;

import com.shopping.veereshmart.entities.Order;

public interface OrderService {
	public Order addOrder(Order order);
	public  List<Order> getOrdersWithProductsByCategory(String category);
}
