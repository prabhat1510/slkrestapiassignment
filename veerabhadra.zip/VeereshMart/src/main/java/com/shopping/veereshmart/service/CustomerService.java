package com.shopping.veereshmart.service;

import com.shopping.veereshmart.entities.Customer;

public interface CustomerService {
	public Customer addCustomer(Customer customer);
	
}
