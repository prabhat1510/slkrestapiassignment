package com.shopping.vmart.service;

import com.shopping.vmart.entities.Customer;

public interface CustomerService {
	public Customer addCustomer(Customer customer);
	
}
