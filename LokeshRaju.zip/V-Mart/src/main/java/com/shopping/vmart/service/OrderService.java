package com.shopping.vmart.service;

import java.util.List;

import com.shopping.vmart.entities.Order;

public interface OrderService {
	public Order addOrder(Order order);
	public  List<Order> getOrdersWithProductsByCategory(String category);
}
