package com.example.retailapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.retailapp.entities.Customer;
import com.example.retailapp.exceptions.CustomerNotFoundException;
import com.example.retailapp.service.CustomerService;


@RestController
public class CustomerController {
	@Autowired
	private CustomerService service;
	
	
	@PostMapping("/newcustomer")
	public Customer addCustomer(@RequestBody Customer customer) {
		return service.addCustomer(customer);
	}
	
	  @GetMapping("/customer/{id}")
	    public ResponseEntity<Customer> getCustomerById(@PathVariable("id") Long customerId) {
	        try {
	            Customer customer = service.retrieveCustomerById(customerId);
	            return new ResponseEntity<>(customer, HttpStatus.OK);
	        } catch (CustomerNotFoundException e) {
	            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
	        }
	  }
}
