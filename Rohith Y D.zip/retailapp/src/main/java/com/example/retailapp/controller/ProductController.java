package com.example.retailapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.retailapp.entities.Product;
import com.example.retailapp.service.ProductService;

@RestController
public class ProductController {
	@Autowired
	private ProductService service;
	
	
	@PostMapping("/newproduct")
	public Product addProduct(@RequestBody Product product) {
		return service.addProduct(product);
	}
	
	 // Retrieve a product by ID
    @GetMapping("/product/{id}")
    public ResponseEntity<Product> getProductById(@PathVariable("id") Long productId) {
        try {
            Product product = service.retrieveProductById(productId);
            return ResponseEntity.ok(product);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    // Get products by category and price greater than 100
    @GetMapping("/products/category/pricegt100")
    public ResponseEntity<List<Product>> getProductsByCategoryAndPriceGTHundred(@RequestParam String category) {
        try {
            List<Product> products = service.getProductsByCategoryAndPriceGTHundred(category);
            return ResponseEntity.ok(products);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    // Get products by category
    @GetMapping("/products/category/{category}")
    public ResponseEntity<List<Product>> getProductsByCategory(@PathVariable String category) {
        try {
            List<Product> products = service.getProductsByCategory(category);
            return ResponseEntity.ok(products);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    // Get products by category with a 10% discount
    @GetMapping("/products/category/discount10/{category}")
    public ResponseEntity<List<Product>> getProductsByCategoryWithDiscountTenPercent(@PathVariable String category) {
        try {
            List<Product> products = service.getProductsByCategoryWithDiscountTenPercent(category);
            return ResponseEntity.ok(products);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

}

