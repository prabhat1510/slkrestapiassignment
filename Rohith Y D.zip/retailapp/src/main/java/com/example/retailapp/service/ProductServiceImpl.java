package com.example.retailapp.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.retailapp.entities.Product;
import com.example.retailapp.exceptions.ProductNotFoundException;
import com.example.retailapp.repositories.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	private ProductRepository repo;
	@Override
	public Product addProduct(Product product) {
		return repo.save(product);
	}

	@Override
	public Product retrieveProductById(Long productId) throws ProductNotFoundException {
		// Retrieve a product by its ID
				Optional<Product> product = repo.findById(productId);
				if (product.isEmpty()) {
					throw new ProductNotFoundException("Product with ID " + productId + " not found.");
				}
				return product.get();
	}

	@Override
	public List<Product> getProducts() {
		 return StreamSupport.stream(repo.findAll().spliterator(), false)
                 .collect(Collectors.toList());
	}

	@Override
	public List<Product> getProductsByCategoryAndPriceGTHundred(String category) throws ProductNotFoundException {
	    List<Product> products = repo.findByCategoryAndPriceGreaterThan(category, 100.0);
	    if (products.isEmpty()) {
	        throw new ProductNotFoundException("No products found in category " + category + " with price greater than 100.");
	    }
	    return products;
	}

	@Override
	public List<Product> getProductsByCategory(String category) throws ProductNotFoundException {
		List<Product> products = repo.findByCategory(category);
		if (products.isEmpty()) {
			throw new ProductNotFoundException("No products found in category " + category);
		}
		return products;
	}

	@Override
	public List<Product> getProductsByCategoryWithDiscountTenPercent(String category) throws ProductNotFoundException {
		List<Product> products = repo.findByCategory(category);
		if (products.isEmpty()) {
			throw new ProductNotFoundException("No products found in category " + category);
		}

		// Apply a 10% discount to the product price
		products = products.stream()
			.map(product -> {
				product.setPrice(product.getPrice() * 0.9); // Applying 10% discount
				return product;
			})
			.collect(Collectors.toList());

		return products;
	}
}
