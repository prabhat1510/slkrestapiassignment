package com.example.retailapp.service;

import java.util.List;

import com.example.retailapp.entities.Product;
import com.example.retailapp.exceptions.ProductNotFoundException;

public interface ProductService {
	public Product addProduct(Product product);
	public Product retrieveProductById(Long orderId) throws ProductNotFoundException;
	public List<Product> getProducts();
	
	public List<Product> getProductsByCategoryAndPriceGTHundred(String category) throws ProductNotFoundException;
	public List<Product> getProductsByCategory(String category) throws ProductNotFoundException;
	public List<Product> getProductsByCategoryWithDiscountTenPercent(String category) throws ProductNotFoundException;
	
}
