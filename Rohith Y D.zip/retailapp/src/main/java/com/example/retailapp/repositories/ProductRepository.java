package com.example.retailapp.repositories;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.retailapp.entities.Product;


@Repository
public interface ProductRepository extends CrudRepository<Product, Long> {

	List<Product> findByCategoryAndPriceGreaterThan(String category, double d);

	List<Product> findByCategory(String category);

	List<Product> findByCustomerTierAndPurchaseDateBetween(String tier, LocalDate date1, LocalDate date2);

	

}
