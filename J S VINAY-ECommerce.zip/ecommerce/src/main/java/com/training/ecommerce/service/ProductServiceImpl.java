package com.training.ecommerce.service;

import java.time.LocalDate;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.ecommerce.entities.Product;
import com.training.ecommerce.exceptions.ProductNotFoundException;
import com.training.ecommerce.repositories.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepository repo;

    @Override
    public Product addProduct(Product product) {
        // Save the product to the repository and return it
        return repo.save(product);
    }

    @Override
    public Product retrieveProductById(Long productId) throws ProductNotFoundException {
        // Retrieve a product by ID. If not found, throw a custom exception
        return repo.findById(productId).orElseThrow(() -> new ProductNotFoundException("Product not found with id: " + productId));
    }

    @Override
    public List<Product> getProducts() {
        // Get all products from the repository
        return (List<Product>) repo.findAll();
    }

    @Override
    public List<Product> getProductsByCategoryAndPriceGTHundred(String category) throws ProductNotFoundException {
        // Fetch products by category
        List<Product> products = repo.findProductByCategory(category);

        // Filter products with price greater than 100
        products = products.stream()
                .filter(product -> product.getPrice() > 100)
                .collect(Collectors.toList());

        // If no products are found, throw an exception
        if (products.isEmpty()) {
            throw new ProductNotFoundException("No products found in category " + category + " with price greater than 100");
        }

        return products;
    }

    @Override
    public List<Product> getProductsByCategory(String category) throws ProductNotFoundException {
        // Fetch products by category
        List<Product> products = repo.findProductByCategory(category);

        // If no products are found, throw an exception
        if (products.isEmpty()) {
            throw new ProductNotFoundException("No products found in category: " + category);
        }

        return products;
    }

    @Override
    public List<Product> getProductsByCategoryWithDiscountTenPercent(String category) throws ProductNotFoundException {
        // Fetch products by category
        List<Product> products = repo.findProductByCategory(category);

        // Apply 10% discount and filter out products that don’t meet the criteria
        products = products.stream()
                .filter(product -> product.getPrice() >= (product.getPrice() * 0.9))
                .collect(Collectors.toList());

        // If no products are found, throw an exception
        if (products.isEmpty()) {
            throw new ProductNotFoundException("No products found in category " + category + " with a discount of 10% or more");
        }

        return products;
    }

  

    @Override
    public List<Product> getCheapestProductByCategory(String category) throws ProductNotFoundException {
        // Fetch products by category
        List<Product> products = repo.findProductByCategory(category);

        // If no products are found, throw an exception
        if (products.isEmpty()) {
            throw new ProductNotFoundException("No products found in category: " + category);
        }

        // Find the cheapest product in the category
        Product cheapestProduct = products.stream()
                .min((product1, product2) -> product1.getPrice().compareTo(product2.getPrice()))
                .orElseThrow(() -> new ProductNotFoundException("No products found in category: " + category));

        return List.of(cheapestProduct); // Return the cheapest product as a list
    }
}
