package com.training.ecommerce.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.training.ecommerce.entities.Product;
import com.training.ecommerce.exceptions.ProductNotFoundException;
import com.training.ecommerce.service.ProductService;



@RestController
public class ProductController {
	@Autowired
	private ProductService service;
	
	
	@PostMapping("/newproduct")
	public Product addProduct(@RequestBody Product product) {
		return service.addProduct(product);
	}

    // GET endpoint to retrieve a product by ID
    @GetMapping("/product/{productId}")
    public ResponseEntity<Product> retrieveProductById(@PathVariable Long productId) {
        try {
            Product product = service.retrieveProductById(productId);
            return new ResponseEntity<>(product, HttpStatus.OK);
        } catch (ProductNotFoundException ex) {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }

    // GET endpoint to retrieve all products
    @GetMapping("/products")
    public ResponseEntity<List<Product>> getProducts() {
        List<Product> products = service.getProducts();
        return new ResponseEntity<>(products, HttpStatus.OK);
    }

    // GET endpoint to retrieve products by category and price > 100
    @GetMapping("/products/category/{category}/priceGreaterThan100")
    public ResponseEntity<List<Product>> getProductsByCategoryAndPriceGTHundred(@PathVariable String category) {
        try {
            List<Product> products = service.getProductsByCategoryAndPriceGTHundred(category);
            return new ResponseEntity<>(products, HttpStatus.OK);
        } catch (ProductNotFoundException ex) {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }

    // GET endpoint to retrieve products by category
    @GetMapping("/products/category/{category}")
    public ResponseEntity<List<Product>> getProductsByCategory(@PathVariable String category) {
        try {
            List<Product> products = service.getProductsByCategory(category);
            return new ResponseEntity<>(products, HttpStatus.OK);
        } catch (ProductNotFoundException ex) {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }

    // GET endpoint to retrieve products by category with a discount of 10%
    @GetMapping("/products/category/{category}/discount10")
    public ResponseEntity<List<Product>> getProductsByCategoryWithDiscountTenPercent(@PathVariable String category) {
        try {
            List<Product> products = service.getProductsByCategoryWithDiscountTenPercent(category);
            return new ResponseEntity<>(products, HttpStatus.OK);
        } catch (ProductNotFoundException ex) {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }

    

    // GET endpoint to retrieve the cheapest product by category
    @GetMapping("/products/category/{category}/cheapest")
    public ResponseEntity<List<Product>> getCheapestProductByCategory(@PathVariable String category) throws ProductNotFoundException {
        List<Product> cheapestProduct = service.getCheapestProductByCategory(category);
		return new ResponseEntity<>(cheapestProduct, HttpStatus.OK);
    }
}