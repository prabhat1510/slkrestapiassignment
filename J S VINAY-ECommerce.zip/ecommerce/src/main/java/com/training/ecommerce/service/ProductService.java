package com.training.ecommerce.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.ecommerce.entities.Product;
import com.training.ecommerce.exceptions.ProductNotFoundException;
import com.training.ecommerce.repositories.ProductRepository;



public interface ProductService {
	public Product addProduct(Product product);
	public Product retrieveProductById(Long orderId) throws ProductNotFoundException;
	public List<Product> getProducts();
	
	public List<Product> getProductsByCategoryAndPriceGTHundred(String category) throws ProductNotFoundException;
	public List<Product> getProductsByCategory(String category) throws ProductNotFoundException;
	public List<Product> getProductsByCategoryWithDiscountTenPercent(String category) throws ProductNotFoundException;
	public List<Product> getCheapestProductByCategory(String category) throws ProductNotFoundException;
}