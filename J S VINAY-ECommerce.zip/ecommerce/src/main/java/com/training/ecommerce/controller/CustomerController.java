package com.training.ecommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.training.ecommerce.entities.Customer;
import com.training.ecommerce.exceptions.CustomerNotFoundException;
import com.training.ecommerce.service.CustomerService;



@RestController
public class CustomerController {
	@Autowired
	private CustomerService service;
	
	
	@PostMapping("/customer/newcustomer")
	public Customer addCustomer(@RequestBody Customer customer) {
		return service.addCustomer(customer);
	}
	 // GET endpoint to retrieve a customer by ID
    @GetMapping("/customer/{customerId}")
    public ResponseEntity<Customer> retrieveCustomerById(@PathVariable Long customerId) {
        try {
            Customer customer = service.retrieveCustomerById(customerId);
            return new ResponseEntity<>(customer, HttpStatus.OK);
        } catch (CustomerNotFoundException ex) {
            // Return a NOT FOUND response if customer doesn't exist
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }

    // GET endpoint to retrieve a list of all customers
    @GetMapping("/customer/customers")
    public ResponseEntity<List<Customer>> getCustomers() {
        List<Customer> customers = service.getCustomers();
        return new ResponseEntity<>(customers, HttpStatus.OK);
    }
}