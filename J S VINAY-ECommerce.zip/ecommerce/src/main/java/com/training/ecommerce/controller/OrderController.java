package com.training.ecommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.training.ecommerce.entities.Order;
import com.training.ecommerce.exceptions.OrderNotFoundException;
import com.training.ecommerce.service.OrderService;


@RestController
public class OrderController {
	@Autowired
	private OrderService service;
	
	
	@PostMapping("/neworder")
	public Order addOrder(@RequestBody Order order) {
		return service.addOrder(order);
	}
	 // GET endpoint to retrieve an order by ID
    @GetMapping("/order/{orderId}")
    public ResponseEntity<Order> retrieveOrderById(@PathVariable Long orderId) {
        try {
            Order order = service.retrieveOrderById(orderId);
            return new ResponseEntity<>(order, HttpStatus.OK);
        } catch (OrderNotFoundException ex) {
            // Return a NOT FOUND response if order doesn't exist
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }

    // GET endpoint to retrieve a list of all orders
    @GetMapping("/orders")
    public ResponseEntity<List<Order>> getOrders() {
        List<Order> orders = service.getOrders();
        return new ResponseEntity<>(orders, HttpStatus.OK);
    }

    
}