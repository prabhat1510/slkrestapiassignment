package com.training.ecommerce.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.training.ecommerce.entities.Product;

@Repository
public interface ProductRepository extends CrudRepository<Product, Long> {
	List<Product> findProductByCategory(String category);

	

}