package com.training.ecommerce.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.ecommerce.entities.Customer;
import com.training.ecommerce.exceptions.CustomerNotFoundException;
import com.training.ecommerce.repositories.CustomerRepository;


public interface CustomerService {
	public Customer addCustomer(Customer customer);
	public Customer retrieveCustomerById(Long customerId) throws CustomerNotFoundException;
	public List<Customer> getCustomers();
}
