package com.training.assignmentsolutions.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.training.assignmentsolutions.entities.Order;
import com.training.assignmentsolutions.exception.OrderNotFoundException;
import com.training.assignmentsolutions.service.OrderService;

@RestController
public class OrderController {

    @Autowired
    private OrderService service;

    // Add a new order
    @PostMapping("/neworder")
    public Order addOrder(@RequestBody Order order) {
        return service.addOrder(order);
    }

    // Retrieve an order by ID
    @GetMapping("/order/{orderId}")
    public Order getOrderById(@PathVariable Long orderId) throws OrderNotFoundException {
        return service.retrieveOrderById(orderId);
    }

    // Retrieve all orders
    @GetMapping("/orders")
    public List<Order> getAllOrders() {
        return service.getOrders();
    }
}
