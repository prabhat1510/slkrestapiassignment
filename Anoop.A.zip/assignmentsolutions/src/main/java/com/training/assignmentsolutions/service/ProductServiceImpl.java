package com.training.assignmentsolutions.service;

import java.time.LocalDate;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.assignmentsolutions.entities.Product;
import com.training.assignmentsolutions.entities.Order;
import com.training.assignmentsolutions.exception.ProductNotFoundException;
import com.training.assignmentsolutions.repositories.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepository repo;

    @Override
    public Product addProduct(Product product) {
        return repo.save(product);
    }

    @Override
    public Product retrieveProductById(Long productId) throws ProductNotFoundException {
        return repo.findById(productId)
                .orElseThrow(() -> new ProductNotFoundException("Product not found with ID: " + productId));
    }

    @Override
    public List<Product> getProducts() {
        return (List<Product>) repo.findAll();
    }

    @Override
    public List<Product> getProductsByCategoryAndPriceGTHundred(String category) throws ProductNotFoundException {
        List<Product> products = repo.findProductByCategory(category)
                .stream()
                .filter(product -> product.getPrice() > 100)
                .collect(Collectors.toList());
        if (products.isEmpty()) {
            throw new ProductNotFoundException("No products found in category '" + category + "' with price > 100");
        }
        return products;
    }

    @Override
    public List<Product> getProductsByCategory(String category) throws ProductNotFoundException {
        List<Product> products = repo.findProductByCategory(category);
        if (products.isEmpty()) {
            throw new ProductNotFoundException("No products found in category: " + category);
        }
        return products;
    }

    @Override
    public List<Product> getProductsByCategoryWithDiscountTenPercent(String category) throws ProductNotFoundException {
        List<Product> products = repo.findProductByCategory(category)
                .stream()
                .peek(product -> product.setPrice(product.getPrice() * 0.9)) // Apply a 10% discount
                .collect(Collectors.toList());
        if (products.isEmpty()) {
            throw new ProductNotFoundException("No products found in category: " + category);
        }
        return products;
    }

    @Override
    public List<Product> getProductsByCustomerTierBetweenTwoDates(String tier, LocalDate date1, LocalDate date2) throws ProductNotFoundException {
        List<Product> products = ((Collection<Product>) repo.findAll())
                .stream()
                .filter(product -> product.getOrders().stream()
                        .anyMatch(order -> 
                            order.getCustomer().getTier().toString().equals(tier) &&
                            order.getOrderDate().isAfter(date1.minusDays(1)) &&
                            order.getOrderDate().isBefore(date2.plusDays(1))
                        ))
                .collect(Collectors.toList());
        if (products.isEmpty()) {
            throw new ProductNotFoundException("No products found for tier '" + tier + "' between dates " + date1 + " and " + date2);
        }
        return products;
    }

    @Override
    public List<Product> getCheapestProductByCategory(String category) {
        List<Product> products = repo.findProductByCategory(category);
        Optional<Product> cheapestProduct = products.stream()
                .min(Comparator.comparing(Product::getPrice));
        return cheapestProduct.map(List::of).orElse(List.of());
    }
}
