package com.training.assignmentsolutions.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.training.assignmentsolutions.entities.Product;
import com.training.assignmentsolutions.exception.ProductNotFoundException;
import com.training.assignmentsolutions.service.ProductService;

@RestController
public class ProductController {

    @Autowired
    private ProductService service;

    // Add a new product
    @PostMapping("/newproduct")
    public Product addProduct(@RequestBody Product product) {
        return service.addProduct(product);
    }

    // Retrieve a product by ID
    @GetMapping("/product/{productId}")
    public Product getProductById(@PathVariable Long productId) throws ProductNotFoundException {
        return service.retrieveProductById(productId);
    }

    // Retrieve all products
    @GetMapping("/products")
    public List<Product> getAllProducts() {
        return service.getProducts();
    }

    // Retrieve products by category and price > 100
    @GetMapping("/products/category/{category}/price-greater-than-hundred")
    public List<Product> getProductsByCategoryAndPriceGTHundred(@PathVariable String category) throws ProductNotFoundException {
        return service.getProductsByCategoryAndPriceGTHundred(category);
    }

    // Retrieve products by category
    @GetMapping("/products/category/{category}")
    public List<Product> getProductsByCategory(@PathVariable String category) throws ProductNotFoundException {
        return service.getProductsByCategory(category);
    }

    // Retrieve products by category with a 10% discount
    @GetMapping("/products/category/{category}/discounted")
    public List<Product> getProductsByCategoryWithDiscount(@PathVariable String category) throws ProductNotFoundException {
        return service.getProductsByCategoryWithDiscountTenPercent(category);
    }

    // Retrieve products by customer tier between two dates
    @GetMapping("/products/tier/{tier}")
    public List<Product> getProductsByCustomerTierBetweenTwoDates(
            @PathVariable String tier,
            @RequestParam("startDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam("endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate)
            throws ProductNotFoundException {
        return service.getProductsByCustomerTierBetweenTwoDates(tier, startDate, endDate);
    }

    // Retrieve the cheapest product by category
    @GetMapping("/products/category/{category}/cheapest")
    public List<Product> getCheapestProductByCategory(@PathVariable String category) {
        return service.getCheapestProductByCategory(category);
    }
}
