package com.training.assignmentsolutions.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;

import com.training.assignmentsolutions.entities.Customer;
import com.training.assignmentsolutions.exception.CustomerNotFoundException;
import com.training.assignmentsolutions.service.CustomerService;

@RestController
public class CustomerController {

    @Autowired
    private CustomerService service;

    // Add a new customer
    @PostMapping("/newcustomer")
    public Customer addCustomer(@RequestBody Customer customer) {
        return service.addCustomer(customer);
    }

    // Retrieve a customer by ID
    @GetMapping("/customer/{customerId}")
    public Customer getCustomerById(@PathVariable Long customerId) throws CustomerNotFoundException {
        return service.retrieveCustomerById(customerId);
    }

    // Retrieve all customers
    @GetMapping("/customers")
    public List<Customer> getAllCustomers() {
        return service.getCustomers();
    }
}
