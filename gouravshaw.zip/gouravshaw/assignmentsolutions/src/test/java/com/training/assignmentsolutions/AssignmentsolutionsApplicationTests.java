package com.training.assignmentsolutions;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssignmentsolutionsApplicationTests {

	@Test
	void contextLoads() {
	}

}
