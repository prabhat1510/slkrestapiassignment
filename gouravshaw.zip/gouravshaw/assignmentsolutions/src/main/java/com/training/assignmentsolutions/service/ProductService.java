package com.training.assignmentsolutions.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestParam;

import com.training.assignmentsolutions.DTO.ProductDTO;
import com.training.assignmentsolutions.entities.Product;
import com.training.assignmentsolutions.exceptions.ProductNotFoundException;

public interface ProductService {
	public Product addProduct(ProductDTO productDTO);
	public Product retrieveProductById(Long orderId) throws ProductNotFoundException;
	public List<Product> getProducts();
	public List<Product> retrieveProductsByIds(List<Long> productIds);
	
	public List<Product> getProductsByCategory(String category) throws ProductNotFoundException;
	public List<Product> getProductsByCategoryWithDiscountTenPercent(String category) throws ProductNotFoundException;
	public List<Product> getProductsByCustomerTierBetweenTwoDates(String tier,LocalDate date1,LocalDate date2) throws ProductNotFoundException;
	public List<Product> getCheapestProductByCategory(String category);
	public List<Product> getProductByParameter(String category, int pricegreaterthan);
	public Product getCheapestByCategory(String category);
	public List<Product> getDiscountbyCategory(String category, int discount);
}