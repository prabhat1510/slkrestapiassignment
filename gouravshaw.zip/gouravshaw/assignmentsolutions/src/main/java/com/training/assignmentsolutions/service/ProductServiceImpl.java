package com.training.assignmentsolutions.service;

import java.time.LocalDate;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import com.training.assignmentsolutions.DTO.ProductDTO;
import com.training.assignmentsolutions.DTOConverter.ProductDTOConverter;
import com.training.assignmentsolutions.entities.Customer;
import com.training.assignmentsolutions.entities.Product;
import com.training.assignmentsolutions.exceptions.CustomerNotFoundException;
import com.training.assignmentsolutions.exceptions.ProductNotFoundException;
import com.training.assignmentsolutions.repositories.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	private ProductRepository repo;
	@Override
	public Product addProduct(ProductDTO product) {
		return repo.save(ProductDTOConverter.toProduct(product));
	}

	@Override
	public Product retrieveProductById(Long productId) throws ProductNotFoundException {
		Optional<Product> product = repo.findById(productId);
		if(product.isPresent()) {
			return product.get();
		}else {
			throw new ProductNotFoundException("Customer with customer id "+productId+" doesn't exists");
		}
	}

	@Override
	public List<Product> retrieveProductsByIds(List<Long> productIds) {
		List<Product> products = new ArrayList<Product>();
		for(Long productId : productIds) {
			Optional<Product> product = repo.findById(productId);
			if(product.isPresent()) {
				products.add(product.get());
			}
		}
		return products;
	}

	@Override
	public List<Product> getProducts() {
		return (List<Product>) repo.findAll();
	}

	@Override
	public List<Product> getProductByParameter(String category, int pricegreaterthan){
		List<Product> products = (List<Product>) repo.findAll();
		List<Product> filteredProducts = new ArrayList<Product>();
		for(Product product : products) {
			if(product.getCategory().equals(category) && product.getPrice() > pricegreaterthan) {
				filteredProducts.add(product);
			}
		}
		return filteredProducts;
	}

	@Override
	public Product getCheapestByCategory(String category) {
		List<Product> products = (List<Product>) repo.findAll();
		Product cheapestProduct = null;
		for(Product product : products) {
			if(product.getCategory().equals(category)) {
				if(cheapestProduct == null) {
					cheapestProduct = product;
				}else {
					if(product.getPrice() < cheapestProduct.getPrice()) {
						cheapestProduct = product;
					}
				}
			}
		}
		return cheapestProduct;
	}

	@Override
	public List<Product> getDiscountbyCategory(String category, int discount){
		List<Product> products = (List<Product>) repo.findAll();
		List<Product> filteredProducts = new ArrayList<Product>();
		for(Product product : products) {
			if(product.getCategory().equals(category)) {
				Product discountedProduct = product;
				discountedProduct.setPrice(product.getPrice() - (product.getPrice() * discount / 100));
				filteredProducts.add(discountedProduct);
			}
		}
		return filteredProducts;
	}

	@Override
	public List<Product> getProductsByCategory(String category) throws ProductNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> getProductsByCategoryWithDiscountTenPercent(String category) throws ProductNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> getProductsByCustomerTierBetweenTwoDates(String tier, LocalDate date1, LocalDate date2)
			throws ProductNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> getCheapestProductByCategory(String category) {
		// TODO Auto-generated method stub
		return null;
	}

}