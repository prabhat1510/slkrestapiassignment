package com.training.assignmentsolutions.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.assignmentsolutions.DTO.OrderDTO;
import com.training.assignmentsolutions.DTOConverter.OrderDTOConverter;
import com.training.assignmentsolutions.entities.Order;
import com.training.assignmentsolutions.exceptions.CustomerNotFoundException;
import com.training.assignmentsolutions.exceptions.OrderNotFoundException;
import com.training.assignmentsolutions.repositories.OrderRepository;

@Service
public class OrderServiceImpl implements OrderService {
	@Autowired
	private OrderRepository repo;
	private CustomerService customerService;
	private ProductService productService;
	
	@Override
	public Order addOrder(OrderDTO order) {
		Order newOrder = OrderDTOConverter.toOrder(order);
		try {
			newOrder.setCustomer(customerService.retrieveCustomerById(order.getCustomerId()));
		} catch (CustomerNotFoundException e) {
			e.printStackTrace();
		}
		newOrder.setProducts(productService.retrieveProductsByIds(order.getProductIds()));
		return repo.save(newOrder);
	}

	@Override
	public Order retrieveOrderById(Long orderId) throws OrderNotFoundException{
		Optional<Order> order = repo.findById(orderId);
		if(order.isPresent()) {
			return order.get();
		}else {
			throw new OrderNotFoundException("Order with order id "+orderId+" doesn't exists");
		}
	}

	@Override
	public List<Order> getOrders() {
		return (List<Order>) repo.findAll();
	}

}