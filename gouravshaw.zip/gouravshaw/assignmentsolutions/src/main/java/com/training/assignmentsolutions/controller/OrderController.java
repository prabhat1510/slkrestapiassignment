package com.training.assignmentsolutions.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.training.assignmentsolutions.DTO.OrderDTO;
import com.training.assignmentsolutions.entities.Order;
import com.training.assignmentsolutions.service.OrderService;
import java.util.List;

@RestController
@RequestMapping("/order")
public class OrderController {
	@Autowired
	private OrderService service;
	
	@GetMapping()
	public List<Order> getOrders() {
		return service.getOrders();
	}

	@PostMapping()
	public Order addOrder(@RequestBody OrderDTO order) {
		return service.addOrder(order);
	}
}