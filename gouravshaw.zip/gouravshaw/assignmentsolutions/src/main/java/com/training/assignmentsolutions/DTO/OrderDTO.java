package com.training.assignmentsolutions.DTO;

import java.time.LocalDate;
import java.util.List;

import com.training.assignmentsolutions.entities.Customer;
import com.training.assignmentsolutions.entities.Order;
import com.training.assignmentsolutions.entities.Product;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class OrderDTO {
    private Long orderId;
    private String status;
    private LocalDate orderDate;
    private LocalDate deliveryDate;
    private List<Long> productIds;
    private Long customerId;
}