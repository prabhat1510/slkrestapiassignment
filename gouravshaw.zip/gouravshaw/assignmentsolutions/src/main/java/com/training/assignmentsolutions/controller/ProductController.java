package com.training.assignmentsolutions.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.training.assignmentsolutions.DTO.ProductDTO;
import com.training.assignmentsolutions.entities.Product;
import com.training.assignmentsolutions.service.ProductService;


@RestController
@RequestMapping("/product")
public class ProductController {
	@Autowired
	private ProductService service;
	
	@PostMapping()
	public Product addProduct(@RequestBody ProductDTO productDTO) {
		return service.addProduct(productDTO);
	}

	@GetMapping()
	public List<Product> getProduct() {
		return service.getProducts();
	}

	@GetMapping("/getProductByParameter")
	public List<Product> getProductByParameter(@RequestParam String category, @RequestParam int pricegreaterthan) {
		return service.getProductByParameter(category, pricegreaterthan);
	}

	@GetMapping("/getCheapestByCategory")
	public ResponseEntity<Product> getCheapestByCategory(@RequestParam String category) {
		return ResponseEntity.ok(service.getCheapestByCategory(category));
	}

	@GetMapping("getDiscountbyCategory")
	public ResponseEntity<List<Product>> getDiscountbyCategory(@RequestParam String category, @RequestParam int discount) {
		return ResponseEntity.ok(service.getDiscountbyCategory(category, discount));
	}

}