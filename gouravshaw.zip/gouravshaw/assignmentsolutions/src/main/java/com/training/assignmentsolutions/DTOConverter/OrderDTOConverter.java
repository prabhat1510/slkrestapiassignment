package com.training.assignmentsolutions.DTOConverter;

import java.util.*;

import com.training.assignmentsolutions.DTO.OrderDTO;
import com.training.assignmentsolutions.entities.Customer;
import com.training.assignmentsolutions.entities.Order;
import com.training.assignmentsolutions.entities.Product;

public class OrderDTOConverter {
    // public static OrderDTO toOrderDTO(Order order) {
    //     OrderDTO orderDTO = new OrderDTO();
    //     orderDTO.setOrderId(order.getOrderId());
    //     orderDTO.setStatus(order.getStatus());
    //     orderDTO.setOrderDate(order.getOrderDate());
    //     orderDTO.setDeliveryDate(order.getDeliveryDate());
    //     List<Long> productIds = new ArrayList<>();
    //     for(Product product : order.getProducts()) {
    //         productIds.add(product.getProductId());
    //     }
    //     orderDTO.setProductIds(productIds);
    //     orderDTO.setCustomerId(order.getCustomer().getCustomerId());
    //     return orderDTO;
    // }

    public static Order toOrder(OrderDTO orderDTO) {
        Order order = new Order();
        order.setOrderId(orderDTO.getOrderId());
        order.setStatus(orderDTO.getStatus());
        order.setOrderDate(orderDTO.getOrderDate());
        order.setDeliveryDate(orderDTO.getDeliveryDate());
        return order;
    }
}
