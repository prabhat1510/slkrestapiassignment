package com.training.assignmentsolutions;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssignmentsolutionsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AssignmentsolutionsApplication.class, args);
	}

}
