package com.training.assignmentsolutions.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.training.assignmentsolutions.DTO.CustomerDTO;
import com.training.assignmentsolutions.entities.Customer;
import com.training.assignmentsolutions.exceptions.CustomerNotFoundException;
import com.training.assignmentsolutions.service.CustomerService;
import java.util.List;

@RestController
@RequestMapping("/customer")
public class CustomerController {
	@Autowired
	private CustomerService service;
	
	@GetMapping("/")
	public List<Customer> getCustomers() {
		return service.getCustomers();
	}
	
	@PostMapping("/")
	public Customer addCustomer(@RequestBody CustomerDTO customerDTO) {
		return service.addCustomer(customerDTO);
	}

	@GetMapping("/{customerId}")
	public Customer retrieveCustomerById(@PathVariable Long customerId) throws CustomerNotFoundException {
		return service.retrieveCustomerById(customerId);
	}

	
}