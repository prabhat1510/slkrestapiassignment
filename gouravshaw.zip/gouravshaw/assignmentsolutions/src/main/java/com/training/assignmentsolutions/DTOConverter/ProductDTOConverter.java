package com.training.assignmentsolutions.DTOConverter;

import com.training.assignmentsolutions.DTO.ProductDTO;
import com.training.assignmentsolutions.entities.Product;

public class ProductDTOConverter {
    public static Product toProduct(ProductDTO productDTO) {
        Product product = new Product();
        product.setName(productDTO.getName());
        product.setCategory(productDTO.getCategory());
        product.setPrice(productDTO.getPrice());
        return product;
    }
}
