package com.training.assignmentsolutions.DTOConverter;

import com.training.assignmentsolutions.DTO.CustomerDTO;
import com.training.assignmentsolutions.entities.Customer;

public class CustomerDTOConverter {
    public static Customer toCustomer(CustomerDTO customerDTO) {
        Customer customer = new Customer();
        customer.setName(customerDTO.getName());
        customer.setEmail(customerDTO.getEmail());
        return customer;
    }
}
