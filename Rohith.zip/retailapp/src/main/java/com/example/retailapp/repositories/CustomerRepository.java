package com.example.retailapp.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.retailapp.entities.Customer;

@Repository
public interface CustomerRepository extends CrudRepository<Customer, Long> {

}
