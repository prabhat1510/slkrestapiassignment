package com.example.retailapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.retailapp.entities.Order;
import com.example.retailapp.exceptions.OrderNotFoundException;
import com.example.retailapp.service.OrderService;

@RestController
public class OrderController {
	@Autowired
	private OrderService service;
	
	
	@PostMapping("/neworder")
	public Order addOrder(@RequestBody Order order) {
		return service.addOrder(order);
	}
	
	 @GetMapping("/order/{id}")
	    public ResponseEntity<Order> getOrderById(@PathVariable("id") Long orderId) {
	        try {
	            Order order = service.retrieveOrderById(orderId);
	            return new ResponseEntity<>(order, HttpStatus.OK);
	        } catch (OrderNotFoundException e) {
	            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
	        }
	    }
}
