package com.example.retailapp.service;

import java.util.List;

import com.example.retailapp.entities.Customer;
import com.example.retailapp.exceptions.CustomerNotFoundException;

public interface CustomerService {
	public Customer addCustomer(Customer customer);
	public Customer retrieveCustomerById(Long customerId) throws CustomerNotFoundException;
	public List<Customer> getCustomers();
}
