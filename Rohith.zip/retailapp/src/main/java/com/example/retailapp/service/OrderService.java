package com.example.retailapp.service;

import java.util.List;

import com.example.retailapp.entities.Order;
import com.example.retailapp.exceptions.OrderNotFoundException;


public interface OrderService {
	public Order addOrder(Order order);
	public Order retrieveOrderById(Long orderId) throws OrderNotFoundException;
	public List<Order> getOrders();
}
