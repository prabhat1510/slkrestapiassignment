package com.example.shoppingapp.service;

import java.util.List;

import com.example.shoppingapp.entities.Order;

public interface OrderService {
	public Order addOrder(Order order);
	public  List<Order> getOrdersWithProductsByCategory(String category);
}
