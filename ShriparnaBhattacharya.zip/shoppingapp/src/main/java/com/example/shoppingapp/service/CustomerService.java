package com.example.shoppingapp.service;

import com.example.shoppingapp.entities.Customer;

public interface CustomerService {
	public Customer addCustomer(Customer customer);
	
}
