package com.example.shoppingapp.service;

import java.time.LocalDate;
import java.util.List;

import com.example.shoppingapp.entities.Product;

public interface ProductService {
    public Product addProduct(Product product);

    // Remove the unnecessary parameter and just return the list
    public List<Product> getExpensiveGames(); // Updated method name for clarity
    
    List<Product> getToysWithDiscount(double discountPercentage);
    
    List<Product> getProductsOrderedByTier2Customers(LocalDate startDate, LocalDate endDate);
    
    List<Product> getCheapestBooks();
}
