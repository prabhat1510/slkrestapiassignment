package com.training.assignmentt.service;



import com.training.assignmentt.entities.Customer;
public interface CustomerService {
	public Customer addCustomer(Customer customer);
	
}

