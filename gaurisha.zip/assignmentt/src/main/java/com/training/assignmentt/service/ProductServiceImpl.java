package com.training.assignmentt.service;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.assignmentt.entities.Product;
import com.training.assignmentt.repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepository productRepo;

    @Override
    public Product addProduct(Product product) {
        return productRepo.save(product);
    }

    @Override
    public List<Product> getExpensiveGames() {
        // No parameter required, just call the repository method
        return productRepo.findExpensiveGames();
    }
    
    @Override
    public List<Product> getToysWithDiscount(double discountPercentage) {
        List<Product> toys = productRepo.findProductsByCategoryToys();
        return toys.stream()
                   .peek(product -> {
                       double discountedPrice = product.getPrice() - (product.getPrice() * (discountPercentage / 100));
                       product.setPrice(discountedPrice);
                   })
                   .collect(Collectors.toList());
    }
    
    @Override
    public List<Product> getProductsOrderedByTier2Customers(LocalDate startDate, LocalDate endDate) {
        return productRepo.findProductsOrderedByTier2CustomersWithinDateRange(startDate, endDate);
    }
    
    @Override
    public List<Product> getCheapestBooks() {
        return productRepo.findCheapestBooks();
    }
}
