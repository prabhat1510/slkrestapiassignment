package com.training.assignmentt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssignmenttApplication {

	public static void main(String[] args) {
		SpringApplication.run(AssignmenttApplication.class, args);
	}
	

}
