package com.training.assignmentt.controller;


import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.training.assignmentt.entities.Product;
import com.training.assignmentt.service.ProductService;



@RestController
@RequestMapping("/product")
public class ProductController {

    @Autowired
    private ProductService service;

    @PostMapping("/addProduct")
    public Product addProduct(@RequestBody Product product) {
        return service.addProduct(product);
    }

    // Get expensive games without needing any request body
    @GetMapping("/Games")
    public List<Product> getExpensiveGames() {
        return service.getExpensiveGames(); // No parameters required
    }
    
    @GetMapping("/ToysWithDiscount")
    public List<Product> getToysWithDiscount(@RequestParam(defaultValue = "10") double discountPercentage) {
        return service.getToysWithDiscount(discountPercentage);
    }
    
    @GetMapping("/Tier2Orders")
    public List<Product> getProductsOrderedByTier2Customers(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
        return service.getProductsOrderedByTier2Customers(startDate, endDate);
    }
    
    @GetMapping("/CheapestBooks")
    public List<Product> getCheapestBooks() {
        return service.getCheapestBooks();
    }
}
