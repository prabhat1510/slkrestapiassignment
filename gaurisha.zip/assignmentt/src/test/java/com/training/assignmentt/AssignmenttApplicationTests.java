package com.training.assignmentt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssignmenttApplicationTests {

	@Test
	void contextLoads() {
	}

}
