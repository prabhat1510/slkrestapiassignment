package com.shopping.vmart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VMartApplication {

	public static void main(String[] args) {
		SpringApplication.run(VMartApplication.class, args);
	}

}
