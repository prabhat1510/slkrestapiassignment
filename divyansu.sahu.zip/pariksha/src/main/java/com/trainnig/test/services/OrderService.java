package com.trainnig.test.services;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.trainnig.test.repositories.OrderRepository;
import com.trainnig.test.entities.Order; // Correct import

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    public List<Order> getOrdersWithBabyCategoryProducts() {
        return orderRepository.findByProductsCategory("Baby");
    }

    public List<Order> getOrdersByCustomerTierAndDateRange(Integer tier, LocalDate startDate, LocalDate endDate) {
        return orderRepository.findByCustomerTierAndOrderDateBetween(tier, startDate, endDate);
    }
}
