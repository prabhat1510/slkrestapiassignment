package com.trainnig.test.repositories;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.trainnig.test.entities.Order; // Correct import
@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {
    List<Order> findByProductsCategory(String category);
    List<Order> findByCustomerTierAndOrderDateBetween(Integer tier, LocalDate startDate, LocalDate endDate);
}
