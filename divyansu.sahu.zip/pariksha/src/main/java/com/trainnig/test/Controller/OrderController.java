package com.trainnig.test.Controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.trainnig.test.entities.Order;
import com.trainnig.test.services.OrderService; 
@RestController
@RequestMapping("/orders")
public class OrderController {

    @Autowired
    private OrderService orderService;
    @GetMapping("/baby-category")
    public List<Order> getOrdersWithBabyCategory() {
        return orderService.getOrdersWithBabyCategoryProducts();
    }
    @GetMapping("/customer/tier/{tier}/date-range")
    public List<Order> getOrdersByCustomerTierAndDateRange(@PathVariable Integer tier, @RequestParam String startDate, @RequestParam String endDate) {
        LocalDate start = LocalDate.parse(startDate);
        LocalDate end = LocalDate.parse(endDate);
        return orderService.getOrdersByCustomerTierAndDateRange(tier, start, end);
    }
}
