package com.trainnig.test.services;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.trainnig.test.entities.Product;
import com.trainnig.test.repositories.ProductRepository;

@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    public List<Product> getBooksWithPriceGreaterThan(Double price) {
        return productRepository.findByCategoryAndPriceGreaterThan("Books", price);
    }

    public List<Product> getToysWithDiscount() {
        List<Product> toys = productRepository.findByCategory("Toys");
        for (Product product : toys) {
            product.setPrice(product.getPrice() * 0.90);  // Apply 10% discount
        }
        return toys;
    }
    public Product addProduct(Product product) {
        return productRepository.save(product); // Saves the product and returns the saved product
    }

    public List<Product> getCheapestBooks() {
        List<Product> books = productRepository.findByCategory("Books");
        return books.stream()
                .min(Comparator.comparing(Product::getPrice))
                .map(Collections::singletonList)
                .orElse(Collections.emptyList());
    }
}
