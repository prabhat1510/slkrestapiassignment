package com.training.demo.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.demo.entities.Order;
import com.training.demo.repositories.OrderRepository;

@Service
public class OrderService {

	@Autowired
    private OrderRepository orderRepository;

    public List<Order> getOrdersByProductCategory(String category) {
        return orderRepository.findByProductsCategory(category);
    }

    public List<Order> getOrdersByCustomerTierAndDateRange(int tier, LocalDate startDate, LocalDate endDate) {
        return orderRepository.findByOrderDateBetweenAndCustomerTier(startDate, endDate, tier);
    }
    
    public Order addOrder(Order order) {
        return orderRepository.save(order);
    }
}