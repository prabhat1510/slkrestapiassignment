package com.training.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.demo.entities.Customer;
import com.training.demo.entities.Order;
import com.training.demo.service.CustomerService;

@RestController
@RequestMapping("/customers")
public class CustomerController {
	@Autowired
    private CustomerService customerService;

    
    @PostMapping("/add")
    public Customer addcustomer(@RequestBody Customer customer) {
        return customerService.addcustomer(customer);
    }
    
}
