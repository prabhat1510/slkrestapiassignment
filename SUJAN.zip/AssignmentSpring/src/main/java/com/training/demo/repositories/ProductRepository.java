package com.training.demo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.training.demo.entities.Product;

public interface ProductRepository extends JpaRepository<Product, Long> {
    List<Product> findByCategoryAndPriceGreaterThan(String category, double price);
    List<Product> findByCategory(String category);
}
