package com.training.demo.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.training.demo.entities.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Long> {
}
