package com.training.demo.repositories;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.training.demo.entities.Order;

public interface OrderRepository extends JpaRepository<Order, Long> {
	 List<Order> findByOrderDateBetweenAndCustomerTier(LocalDate startDate, LocalDate endDate, Integer tier);

	    List<Order> findByProductsCategory(String category);
}