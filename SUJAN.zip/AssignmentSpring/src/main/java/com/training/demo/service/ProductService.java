package com.training.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.demo.entities.Product;
import com.training.demo.repositories.ProductRepository;

@Service
public class ProductService {

	@Autowired
    private ProductRepository productRepository;

    public List<Product> getProductsByCategoryAndPrice(String category, double price) {
        return productRepository.findByCategoryAndPriceGreaterThan(category, price);
    }

    public List<Product> getProductsByCategory(String category) {
        return productRepository.findByCategory(category);
    }

    public Product getCheapestBook() {
        return productRepository.findByCategory("Books").stream()
                .min((p1, p2) -> Double.compare(p1.getPrice(), p2.getPrice()))
                .orElse(null);
    }
    public Product addProduct(Product product) {
        return productRepository.save(product);
    }
}