package com.training.demo.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.demo.entities.Customer;
import com.training.demo.entities.Order;
import com.training.demo.repositories.CustomerRepository;
import com.training.demo.repositories.OrderRepository;

@Service
public class CustomerService {
	@Autowired
    private CustomerRepository customerRepository;

    
    public Customer addcustomer(Customer customer) {
        return customerRepository.save(customer);
    }
}
