package com.training.demo.controller;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.training.demo.entities.Order;
import com.training.demo.entities.Product;
import com.training.demo.service.OrderService;


@RestController
@RequestMapping("/orders")
public class OrderController {

    @Autowired
    private OrderService orderService;

    
    @PostMapping("/add")
    public Order addOrder(@RequestBody Order order) {
        return orderService.addOrder(order);
    }
    
    @GetMapping("/baby")
    public List<Order> getOrdersWithBabyProducts() {
        return orderService.getOrdersByProductCategory("Baby");
    }

    
    @GetMapping("/tier2")
    public List<Order> getOrdersByTier2Customers(
            @RequestParam String startDate, 
            @RequestParam String endDate) {

        LocalDate start = LocalDate.parse(startDate);
        LocalDate end = LocalDate.parse(endDate);

        return orderService.getOrdersByCustomerTierAndDateRange(2, start, end);
    }
}